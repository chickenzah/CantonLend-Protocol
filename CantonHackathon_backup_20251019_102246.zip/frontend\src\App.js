// File: frontend/src/App.js

import React from "react";
import "./App.css";

function App() {
  return (
    <div style={{ padding: "2rem", fontFamily: "Arial, sans-serif" }}>
      <h1>CantonLend Protocol</h1>
      <p>
        CantonLend is a decentralized lending and borrowing prototype built on
        the Canton Network using DAML. It provides a secure,
        privacy-preserving, and compliant way to lend and borrow digital assets
        in a regulated environment.
      </p>

      <h2>Key Features</h2>
      <ul>
        <li>Decentralized lending and borrowing using DAML smart contracts</li>
        <li>Privacy-preserving transactions visible only to authorized participants</li>
        <li>Automated settlements through DAML templates</li>
        <li>Transparent and auditable ledger with confidentiality</li>
        <li>Ready for regulated financial use cases</li>
      </ul>

      <h2>Technology Stack</h2>
      <ul>
        <li>Smart Contracts: DAML</li>
        <li>Network: Canton</li>
        <li>Backend API: Canton JSON API</li>
        <li>Frontend: React</li>
        <li>Automation: PowerShell Scripts</li>
      </ul>

      <h2>Developer Info</h2>
      <ul>
        <li>Developer: chickenza</li>
        <li>Hackathon: Canton Core Ideathon 2025</li>
        <li>Track: Lending, Borrowing & Yield Applications</li>
        <li>Date: October 2025</li>
      </ul>
    </div>
  );
}

export default App;
